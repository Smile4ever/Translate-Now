(function(a,b){if("function"==typeof define&&define.amd)define("webextension-polyfill",["module"],b);else if("undefined"!=typeof exports)b(module);else{var c={exports:{}};b(c),a.browser=c.exports}})("undefined"==typeof globalThis?"undefined"==typeof self?this:self:globalThis,function(a){"use strict";if(!globalThis.chrome?.runtime?.id)throw new Error("This script should only be loaded in a browser extension.");if("undefined"==typeof globalThis.browser||Object.getPrototypeOf(globalThis.browser)!==Object.prototype){a.exports=(a=>{const b={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(0===Object.keys(b).length)throw new Error("api-metadata.json has not been included in browser-polyfill");class c extends WeakMap{constructor(a,b=void 0){super(b),this.createItem=a}get(a){return this.has(a)||this.set(a,this.createItem(a)),super.get(a)}}const d=a=>a&&"object"==typeof a&&"function"==typeof a.then,e=(b,c)=>(...d)=>{a.runtime.lastError?b.reject(new Error(a.runtime.lastError.message)):c.singleCallbackArg||1>=d.length&&!1!==c.singleCallbackArg?b.resolve(d[0]):b.resolve(d)},f=a=>1==a?"argument":"arguments",g=(a,b)=>function(c,...d){if(d.length<b.minArgs)throw new Error(`Expected at least ${b.minArgs} ${f(b.minArgs)} for ${a}(), got ${d.length}`);if(d.length>b.maxArgs)throw new Error(`Expected at most ${b.maxArgs} ${f(b.maxArgs)} for ${a}(), got ${d.length}`);return new Promise((f,g)=>{if(b.fallbackToNoCallback)try{c[a](...d,e({resolve:f,reject:g},b))}catch(e){console.warn(`${a} API method doesn't seem to support the callback parameter, `+"falling back to call it without a callback: ",e),c[a](...d),b.fallbackToNoCallback=!1,b.noCallback=!0,f()}else b.noCallback?(c[a](...d),f()):c[a](...d,e({resolve:f,reject:g},b))})},h=(a,b,c)=>new Proxy(b,{apply(b,d,e){return c.call(d,a,...e)}});let i=Function.call.bind(Object.prototype.hasOwnProperty);const j=(a,b={},c={})=>{let d=Object.create(null),e=Object.create(a);return new Proxy(e,{has(b,c){return c in a||c in d},get(e,f){if(f in d)return d[f];if(!(f in a))return;let k=a[f];if("function"==typeof k){if("function"==typeof b[f])k=h(a,a[f],b[f]);else if(i(c,f)){let b=g(f,c[f]);k=h(a,a[f],b)}else k=k.bind(a);}else if("object"==typeof k&&null!==k&&(i(b,f)||i(c,f)))k=j(k,b[f],c[f]);else if(i(c,"*"))k=j(k,b[f],c["*"]);else return Object.defineProperty(d,f,{configurable:!0,enumerable:!0,get(){return a[f]},set(b){a[f]=b}}),k;return d[f]=k,k},set(b,c,e){return c in d?d[c]=e:a[c]=e,!0},defineProperty(a,b,c){return Reflect.defineProperty(d,b,c)},deleteProperty(a,b){return Reflect.deleteProperty(d,b)}})},k=a=>({addListener(b,c,...d){b.addListener(a.get(c),...d)},hasListener(b,c){return b.hasListener(a.get(c))},removeListener(b,c){b.removeListener(a.get(c))}}),l=new c(a=>"function"==typeof a?function(b){const c=j(b,{},{getContent:{minArgs:0,maxArgs:0}});a(c)}:a),m=new c(a=>"function"==typeof a?function(b,c,e){let f,g,h=!1,i=new Promise(a=>{f=function(b){h=!0,a(b)}});try{g=a(b,c,f)}catch(a){g=Promise.reject(a)}const j=!0!==g&&d(g);if(!0!==g&&!j&&!h)return!1;const k=a=>{a.then(a=>{e(a)},a=>{let b;b=a&&(a instanceof Error||"string"==typeof a.message)?a.message:"An unexpected error occurred",e({__mozWebExtensionPolyfillReject__:!0,message:b})}).catch(a=>{console.error("Failed to send onMessage rejected reply",a)})};return j?k(g):k(i),!0}:a),n=({reject:b,resolve:c},d)=>{a.runtime.lastError?a.runtime.lastError.message==="The message port closed before a response was received."?c():b(new Error(a.runtime.lastError.message)):d&&d.__mozWebExtensionPolyfillReject__?b(new Error(d.message)):c(d)},o=(a,b,c,...d)=>{if(d.length<b.minArgs)throw new Error(`Expected at least ${b.minArgs} ${f(b.minArgs)} for ${a}(), got ${d.length}`);if(d.length>b.maxArgs)throw new Error(`Expected at most ${b.maxArgs} ${f(b.maxArgs)} for ${a}(), got ${d.length}`);return new Promise((a,b)=>{const e=n.bind(null,{resolve:a,reject:b});d.push(e),c.sendMessage(...d)})},p={devtools:{network:{onRequestFinished:k(l)}},runtime:{onMessage:k(m),onMessageExternal:k(m),sendMessage:o.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:o.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},q={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return b.privacy={network:{"*":q},services:{"*":q},websites:{"*":q}},j(a,p,b)})(chrome)}else a.exports=globalThis.browser});
//# sourceMappingURL=browser-polyfill.min.js.map

// webextension-polyfill v.0.10.0 (https://github.com/mozilla/webextension-polyfill)

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
/* Methods in the googletranslate object can be used anywhere */
let googletranslate = {
	getSpeakUrlSource: function(language, newText){
		let speakUrl = "https://translate.google.com/translate_tts?tl=" + language + "&client=tw-ob&q=" + newText;
		
		return speakUrl;
	}
}
/// Static variables
let selectedText = "";
let globalAction = "";
let lastTabs = [];

// Feature discovery
let useOpenerTabId = true;
let browserInfoAvailable = true;
let android = false;
let firefoxAndroid = false;

//the addons icon is a modified version of http://www.flaticon.com/free-icon/translator-tool_69101
//see their website for licensing information

let initDone = false;
let translate_now_destination_language;
let translate_now_source_language;
let translate_now_reuse_tab;
let translate_now_reuse_tab_all;
let translate_now_related_tabs;
let translate_now_translate_engine;
let translate_now_google_speak_audio_only;
let translate_now_to_speak;
let translate_now_context_selection;
let translate_now_context_page;
let translate_now_context_link;

let translate_now_show_deepl_translator;
let translate_now_show_bing_translator;
let translate_now_show_google_translate;

let translate_now_show_google_translate_voice;
let translate_now_show_bing_translator_voice;
let translate_now_show_deepl_translator_voice;

async function init(){
	let valueOrDefault = function(value, defaultValue){
		return value == undefined ? defaultValue : value;
	}

	let result = await browser.storage.local.get([
		"translate_now_destination_language",
		"translate_now_source_language",
		"translate_now_reuse_tab",
		"translate_now_reuse_tab_all",
		"translate_now_related_tabs",
		"translate_now_translate_engine",
		"translate_now_google_speak_audio_only",
		"translate_now_to_speak",
		"translate_now_context_selection",
		"translate_now_context_page",
		"translate_now_context_link",
		"translate_now_show_deepl_translator",
		"translate_now_show_bing_translator",
		"translate_now_show_google_translate",
		"translate_now_show_google_translate_voice",
		"translate_now_show_bing_translator_voice",
		"translate_now_show_deepl_translator_voice"
	]);
	
	translate_now_destination_language = valueOrDefault(result.translate_now_destination_language, "en");
	translate_now_source_language = valueOrDefault(result.translate_now_source_language, "auto");
	translate_now_reuse_tab = valueOrDefault(result.translate_now_reuse_tab, true);
	translate_now_reuse_tab_all = valueOrDefault(result.translate_now_reuse_tab_all, false);
	translate_now_related_tabs = valueOrDefault(result.translate_now_related_tabs, true);
	translate_now_enable_speak = valueOrDefault(result.translate_now_enable_speak, false);
	translate_now_translate_engine = valueOrDefault(result.translate_now_translate_engine, "google");
	translate_now_google_speak_audio_only = valueOrDefault(result.translate_now_google_speak_audio_only, false);
	translate_now_to_speak = valueOrDefault(result.translate_now_to_speak, "both");
	translate_now_context_selection = valueOrDefault(result.translate_now_context_selection, true);
	translate_now_context_page = valueOrDefault(result.translate_now_context_page, true);
	translate_now_context_link = valueOrDefault(result.translate_now_context_link, true);

	translate_now_show_deepl_translator = valueOrDefault(result.translate_now_show_deepl_translator, false);
	translate_now_show_bing_translator = valueOrDefault(result.translate_now_show_bing_translator, false);
	translate_now_show_google_translate = valueOrDefault(result.translate_now_show_google_translate, true);

	translate_now_show_google_translate_voice = valueOrDefault(result.translate_now_show_google_translate_voice, false);
	translate_now_show_bing_translator_voice = valueOrDefault(result.translate_now_show_bing_translator_voice, false);
	translate_now_show_deepl_translator_voice = valueOrDefault(result.translate_now_show_deepl_translator_voice, false);

	await initPlatform();
	await initContextMenus();

	function format(translate_engine){
		if(translate_engine == "google") return "Google Translate";
		if(translate_engine == "bing") return "Bing Translator";
		if(translate_engine == "deepl") return "DeepL Translator";
	}

	browser.action.setTitle({title: "Translate Now - " + format(translate_now_translate_engine)});
	initDone = true;
}
init();

///Messages
// listen for messages from the content or options script
browser.runtime.onMessage.addListener(function(message) {
	switch (message.action) {
		case "refresh-options":
			init();
			break;
		case "setSelection":
			setSelection(message.data.selection, message.data.pageUrl);
			break;
		case "notify":
			notify(message.data);
			break;
		case "log":
			//console.log("translatenow.js: received from content script: " + message.data);
			break;
		case "logOptions":
			//console.log("translatenow.js: received from options script: " + message.data);
			break;
		default:
			break;
	}
});

// See also https://developer.mozilla.org/en-US/Add-ons/WebExtensions/API/Tabs/sendMessage
async function sendMessage(action, data, errorCallback){
	let tabs = await browser.tabs.query({currentWindow: true, active: true});
	for (tab of tabs) {
		browser.tabs.sendMessage(tab.id, {"action": action, "data": data}).catch(function(){
			console.error("Sendmessage failed, check the content script for syntax errors or check the addon permissions in Firefox. Action: " + action + " to " + tab.url + " with data " + JSON.stringify(data));
			if(errorCallback) errorCallback(data, tab.url);
		});
	}
}

/// Init (platform info, context menus)
async function initPlatform(){
	if(browser.runtime.getBrowserInfo == null){
		browserInfoAvailable = false;
	}

	let platformInfo = await browser.runtime.getPlatformInfo();
	let browserInfo = await browser.runtime.getBrowserInfo();
	if(platformInfo.os == "android"){
		android = true;
		if(browserInfo.name.includes("Firefox")){
			firefoxAndroid = true;
			useOpenerTabId = false;
		}
	}
}

async function initContextMenus(){
	if(browser.contextMenus == undefined) return;

	browser.contextMenus.removeAll();

	let selectionPageContext = [];
	let selectionContext = [];

	if(translate_now_context_selection)	selectionPageContext.push("selection");
	if(translate_now_context_selection)	selectionContext.push("selection");
	if(translate_now_context_page) selectionPageContext.push("page");
	if(translate_now_context_link) selectionPageContext.push("link");

	if(translate_now_show_bing_translator)
		createContextMenu("translatenow-bing-translate", "Translate with Bing", selectionContext, "icons/engines/bing.png");
	if(translate_now_show_deepl_translator)
		createContextMenu("translatenow-deepl-translate", "Translate with DeepL", selectionContext, "icons/engines/deepl.png");
	if(translate_now_show_google_translate)
		createContextMenu("translatenow-google-translate", "Translate with Google", selectionPageContext, "icons/engines/google.png");
	
	//if(translate_now_show_bing_translator_voice)
	//	createContextMenu("translatenow-bing-speak", "Speak with Bing Translator Voice", selectionContext, "icons/engines/bing.png");
	//if(translate_now_show_deepl_translator_voice)
	//	createContextMenu("translatenow-deepl-speak", "Speak with Deepl Translator Voice", selectionContext, "icons/engines/deepl.png");
	//if(translate_now_show_google_translate_voice)
	//	createContextMenu("translatenow-google-speak", "Speak with Google Translate Voice", selectionContext, "icons/engines/google.png");
}

function createContextMenu(id, title, contexts, icon64){
	if(icon64 != null && browserInfoAvailable){
		browser.contextMenus.create({
			id: id,
			title: title,
			contexts: contexts,
			icons: {
				"64": browser.runtime.getURL(icon64)
			},
			documentUrlPatterns: ["http://*/*", "https://*/*"]
		});
	}else{
		browser.contextMenus.create({
			id: id,
			title: title,
			contexts: contexts,
			documentUrlPatterns: ["http://*/*", "https://*/*"]
		});
	}
}

async function listener(info,tab){
	if(initDone == false) await init();
	
	if(info.menuItemId == "translatenow-tb-preferences"){
		browser.runtime.openOptionsPage();
		return;
	}

	let selectionText = "";
	let pageUrl = "";

	// Don't fill pageUrl when we won't be using it.
	if(info.selectionText != "" && info.selectionText != null){
		selectionText = info.selectionText;
	}else{
		if(info.pageUrl != "" && info.pageUrl != null)
			pageUrl = info.pageUrl;

		if(info.linkUrl != "" && info.linkUrl != null)
			pageUrl = info.linkUrl;
	}
	
	doClick(selectionText, pageUrl, info.menuItemId.replace("translatenow-", ""));
}

browser.contextMenus.onClicked.removeListener(listener);
browser.contextMenus.onClicked.addListener(listener);

async function clickToolbarButton(){
	if(initDone == false) await init();

	if(translate_now_translate_engine != null){
		globalAction = translate_now_translate_engine + "-translate";

		// selectionText is unknown at this point, so pass an empty string
		sendMessage("getSelection", "", priviledgedSiteNoContentScript);
	}
}

browser.action.onClicked.addListener(clickToolbarButton);

async function openTab(url){
	if(lastTabs.length > 0 && translate_now_reuse_tab){
		let toBeOpenedHostname = new URL(url).hostname;

		// Look for tabs in lastTabs where hostname is equal to the to-be-opened one
		// when translate_now_reuse_tab_all is set to true, it will overwrite this again
		let lastTabPromises = lastTabs.map(lastTab => browser.tabs.get(lastTab.id));

		let tabs = await Promise.all(lastTabPromises);
		let equalTabs = tabs.filter(function currentHostnameMatchesToBeOpened(tab) {
			return new URL(tab.url).hostname == toBeOpenedHostname;
		});

		if(translate_now_reuse_tab_all){
			equalTabs = tabs;
		}

		if(equalTabs.length > 0){
			let lastEqualTab = equalTabs.pop();
			browser.tabs.update(lastEqualTab.id, {
				active: true,
				url: url
			});
			browser.windows.update(lastEqualTab.windowId, {
				focused: true
			});
			
		}else{
			openFocusedTab(url);
		}

	}else{
		openFocusedTab(url);
	}
}

async function openFocusedTab(url){
	let tabs = await browser.tabs.query({currentWindow: true, active: true});
	let createProperties = {
		url: url,
		active: true
	};

	if(translate_now_related_tabs && useOpenerTabId){
		createProperties.openerTabId = tabs[0].id;
	}

	let tab = await browser.tabs.create(createProperties);
	// tab.url is about:blank at the creation time, use "url" variable instead
	lastTabs.push({id: tab.id, url: url});
}

function handleRemoved(tabId, removeInfo) {
	// Remove closed tabs from the lastTabs array
	lastTabs = lastTabs.filter(lastTab => lastTab.id != tabId);
}

browser.tabs.onRemoved.addListener(handleRemoved);

function doClick(selectionText, pageUrl, action){
	globalAction = action;

	// Ideally, we want to use selectionText this which also works for cross-domain iframes (nice!!)
	// But we now use a content script if the selection is too long to circumvent https://bugzilla.mozilla.org/show_bug.cgi?id=1338898

	if(pageUrl != "" || (selectionText.length > 0 && selectionText.length != 16384))
		doAction(selectionText, pageUrl, action);
	else
		sendMessage("getSelection", selectionText, priviledgedSiteNoContentScript);
}

function priviledgedSiteNoContentScript(selectionText, pageUrl){
	// We are probably on addons.mozilla.org or another priviledged website
	//notify("This website is not supported due to security restrictions.");
	
	// Support for addons.mozilla.org among other websites (best effort)
	doAction(selectionText, pageUrl, globalAction);
}

function isTranslationPage(pageUrl){
	return pageUrl.includes(".translate.goog") || pageUrl.includes("://www.deepl.com") || pageUrl.includes("://www.bing.com/translator");
}

function isInvalidPage(pageUrl){
	return pageUrl.includes("about:") || pageUrl.includes("moz-extension://") || pageUrl.includes("chrome:") || pageUrl.includes("chrome-extension://");
}

function doAction(selectionText, pageUrl, action){
	let isURL = false;
	if(selectionText != "" && selectionText != null){
		selectedText = selectionText;
		// If user opted to show the context menu for translating links,
		// check if the selection is a valid URL, if so translate as link
		if(translate_now_context_link && /^\s*https?:\/\/\S+\s*$/i.test(selectedText)){
			try{
				selectedText = new URL(selectedText.trim()).href;
				isURL = true;
			}catch(e){}
		}
	}else{
		if(pageUrl != "" && pageUrl != null){
			if(isTranslationPage(pageUrl) || isInvalidPage(pageUrl)){
				notify("This page cannot be translated, opening a new translation page.");
				selectedText = "";
				isURL = false;
			}else{
				if(action == "bing-translate"){
					notify("Bing cannot translate whole pages, using Google Translate instead.");
				}
				if(action == "deepl-translate"){
					notify("DeepL cannot translate whole pages, using Google Translate instead.");
				}
				
				if(action == "bing-translate" || action == "deepl-translate"){
					globalAction = "google-translate";
					action = "google-translate";
				}
				selectedText = pageUrl;
				isURL = true;
			}
		}else{
			notify("Please try another selection.");
			return;
		}
	}
	
	if(selectedText.length > 1500 && action.includes("deepl") && action.includes("translate")){
		notify("Selected text is too long. Only the first 1500 selected characters will be translated.");
	}
	
	if(selectedText.length > 5000 && action.includes("deepl") == false && action.includes("translate")){
		notify("Selected text is too long. Only the first 5000 selected characters will be translated.");
	}
	
	let newText = getNewText(selectedText);

	if(action == "google-speak"){
		if(selectedText.length > 195){
			notify("Selected text is too long. Only the first 195 characters will be spoken.");
		}
			
		if(translate_now_google_speak_audio_only){
			if(translate_now_source_language == "auto") translate_now_source_language = "en";
			let newTextSpeak = getNewTextSpeak(selectedText);
			openTab(googletranslate.getSpeakUrlSource(translate_now_source_language, newTextSpeak)); // Since we are not translating anything, use the source language
		}else{
			// Using HTTP instead of HTTPS, to trigger Firefox HTTP -> HTTPS redirect. Otherwise, the old text is retained. See bug 18. https://github.com/Smile4ever/firefoxaddons/issues/18
			//openTab("http://translate.google.com/#" + translate_now_source_language + "/" + translate_now_destination_language + "/" + newText);
			// Use new URL structure, see bug 156. https://github.com/Smile4ever/firefoxaddons/issues/156
			openTab("http://translate.google.com/#view=home&op=translate&sl=" + translate_now_source_language + "&tl=" + translate_now_destination_language + "&text=" + newText);
			
			browser.tabs.onUpdated.addListener(pageLoaded);
			setTimeout(function(){
				// Remove the listener when the page fails to load within 5 seconds
				browser.tabs.onUpdated.removeListener(pageLoaded);
			}, 5000);
		}
	}
	
	if(action == "google-translate"){
		if(isURL){
			//openTab("https://translate.google.com/translate?sl=" + translate_now_source_language + "&tl=" + translate_now_destination_language + "&js=y&prev=_t&ie=UTF-8&u=" + newText);
			openTab("https://translate.google.com/translate?hl=" + translate_now_source_language + "&sl=" + translate_now_source_language + "&tl=" + translate_now_destination_language + "&u=" + newText);
		}else{
			// Using HTTP instead of HTTPS, to trigger Firefox HTTP -> HTTPS redirect. Otherwise, the old text is retained. See bug 18. https://github.com/Smile4ever/firefoxaddons/issues/18
			//openTab("http://translate.google.com/#" + translate_now_source_language + "/" + translate_now_destination_language + "/" + newText);
			// Use new URL structure, see bug 156. https://github.com/Smile4ever/firefoxaddons/issues/156
			openTab("http://translate.google.com/#view=home&op=translate&sl=" + translate_now_source_language + "&tl=" + translate_now_destination_language + "&text=" + newText);
		}
	}
	
	if(action.includes("bing")){
		openTab("https://www.bing.com/translator");
		browser.tabs.onUpdated.addListener(pageLoaded);
		setTimeout(function(){
			// Remove the listener when the page fails to load within 5 seconds
			browser.tabs.onUpdated.removeListener(pageLoaded);
		}, 5000);
	}

	if(action.includes("deepl")){
		let sourceLanguage = translate_now_source_language == "auto" ? "en" : translate_now_source_language;
		openTab("https://www.deepl.com/translator#" + sourceLanguage + "/" + translate_now_destination_language + "/" + newText);

		if(action == "deepl-speak"){
			sendMessage("deeplSpeak", {
				translate_now_source_language: translate_now_source_language,
				translate_now_destination_language: translate_now_destination_language,
				selectedText: selectedText,
				translate_now_to_speak: translate_now_to_speak
			});
		}
	}
}

function pageLoaded(tabId, changeInfo, tabInfo){
	if(tabInfo.status != "complete" || tabInfo.status == "interactive") return;
	
	if(tabInfo.url.includes("https://www.bing.com/translator")){
		if(globalAction == "bing-translate"){
			sendMessage("bingTranslate", {
				translate_now_source_language: translate_now_source_language,
				translate_now_destination_language: translate_now_destination_language,
				selectedText: selectedText
			});
		}
		if(globalAction == "bing-speak"){
			sendMessage("bingSpeak", {
				translate_now_source_language: translate_now_source_language,
				translate_now_destination_language: translate_now_destination_language,
				selectedText: selectedText,
				translate_now_to_speak: translate_now_to_speak
			});
		}
		
		browser.tabs.onUpdated.removeListener(pageLoaded);
	}

	// HTTP -> HTTPS redirect
	if(tabInfo.url.includes("translate.goog")){
		if(globalAction == "google-speak")
			sendMessage("googleSpeak", {
				translate_now_source_language: translate_now_source_language,
				translate_now_destination_language: translate_now_destination_language,
				translate_now_to_speak: translate_now_to_speak
			});
		browser.tabs.onUpdated.removeListener(pageLoaded);
	}
}

function setSelection(selectionText, pageUrl){
	doAction(selectionText, pageUrl, globalAction);
}

function getNewText(text){
	let newText = text;
	newText = encodeURIComponent(newText);
	newText = newText.replace("%25", "");
	newText = newText.replace("%C2%A0", " ");
	
	return newText;
}

function getNewTextSpeak(text){
	let newText = getNewText(text.substring(0, 195));
	
	return newText;
}

/// Helper functions
function notify(message){
	let messageId = message.substring(0, 20).replace(" ", "");
	browser.notifications.create(messageId,
	{
		type: "basic",
		iconUrl: browser.runtime.getURL("icons/translatenow-64.png"),
		title: "Translate Now",
		message: message
	});
	setTimeout(function(){
		browser.notifications.clear(messageId);
	}, 5000);
}
