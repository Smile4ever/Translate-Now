(function(a,b){if("function"==typeof define&&define.amd)define("webextension-polyfill",["module"],b);else if("undefined"!=typeof exports)b(module);else{var c={exports:{}};b(c),a.browser=c.exports}})("undefined"==typeof globalThis?"undefined"==typeof self?this:self:globalThis,function(a){"use strict";if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(!(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)){a.exports=(a=>{const b={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(0===Object.keys(b).length)throw new Error("api-metadata.json has not been included in browser-polyfill");class c extends WeakMap{constructor(a,b=void 0){super(b),this.createItem=a}get(a){return this.has(a)||this.set(a,this.createItem(a)),super.get(a)}}const d=a=>a&&"object"==typeof a&&"function"==typeof a.then,e=(b,c)=>(...d)=>{a.runtime.lastError?b.reject(new Error(a.runtime.lastError.message)):c.singleCallbackArg||1>=d.length&&!1!==c.singleCallbackArg?b.resolve(d[0]):b.resolve(d)},f=a=>1==a?"argument":"arguments",g=(a,b)=>function(c,...d){if(d.length<b.minArgs)throw new Error(`Expected at least ${b.minArgs} ${f(b.minArgs)} for ${a}(), got ${d.length}`);if(d.length>b.maxArgs)throw new Error(`Expected at most ${b.maxArgs} ${f(b.maxArgs)} for ${a}(), got ${d.length}`);return new Promise((f,g)=>{if(b.fallbackToNoCallback)try{c[a](...d,e({resolve:f,reject:g},b))}catch(e){console.warn(`${a} API method doesn't seem to support the callback parameter, `+"falling back to call it without a callback: ",e),c[a](...d),b.fallbackToNoCallback=!1,b.noCallback=!0,f()}else b.noCallback?(c[a](...d),f()):c[a](...d,e({resolve:f,reject:g},b))})},h=(a,b,c)=>new Proxy(b,{apply(b,d,e){return c.call(d,a,...e)}});let i=Function.call.bind(Object.prototype.hasOwnProperty);const j=(a,b={},c={})=>{let d=Object.create(null),e=Object.create(a);return new Proxy(e,{has(b,c){return c in a||c in d},get(e,f){if(f in d)return d[f];if(!(f in a))return;let k=a[f];if("function"==typeof k){if("function"==typeof b[f])k=h(a,a[f],b[f]);else if(i(c,f)){let b=g(f,c[f]);k=h(a,a[f],b)}else k=k.bind(a);}else if("object"==typeof k&&null!==k&&(i(b,f)||i(c,f)))k=j(k,b[f],c[f]);else if(i(c,"*"))k=j(k,b[f],c["*"]);else return Object.defineProperty(d,f,{configurable:!0,enumerable:!0,get(){return a[f]},set(b){a[f]=b}}),k;return d[f]=k,k},set(b,c,e){return c in d?d[c]=e:a[c]=e,!0},defineProperty(a,b,c){return Reflect.defineProperty(d,b,c)},deleteProperty(a,b){return Reflect.deleteProperty(d,b)}})},k=a=>({addListener(b,c,...d){b.addListener(a.get(c),...d)},hasListener(b,c){return b.hasListener(a.get(c))},removeListener(b,c){b.removeListener(a.get(c))}}),l=new c(a=>"function"==typeof a?function(b){const c=j(b,{},{getContent:{minArgs:0,maxArgs:0}});a(c)}:a),m=new c(a=>"function"==typeof a?function(b,c,e){let f,g,h=!1,i=new Promise(a=>{f=function(b){h=!0,a(b)}});try{g=a(b,c,f)}catch(a){g=Promise.reject(a)}const j=!0!==g&&d(g);if(!0!==g&&!j&&!h)return!1;const k=a=>{a.then(a=>{e(a)},a=>{let b;b=a&&(a instanceof Error||"string"==typeof a.message)?a.message:"An unexpected error occurred",e({__mozWebExtensionPolyfillReject__:!0,message:b})}).catch(a=>{console.error("Failed to send onMessage rejected reply",a)})};return j?k(g):k(i),!0}:a),n=({reject:b,resolve:c},d)=>{a.runtime.lastError?a.runtime.lastError.message==="The message port closed before a response was received."?c():b(new Error(a.runtime.lastError.message)):d&&d.__mozWebExtensionPolyfillReject__?b(new Error(d.message)):c(d)},o=(a,b,c,...d)=>{if(d.length<b.minArgs)throw new Error(`Expected at least ${b.minArgs} ${f(b.minArgs)} for ${a}(), got ${d.length}`);if(d.length>b.maxArgs)throw new Error(`Expected at most ${b.maxArgs} ${f(b.maxArgs)} for ${a}(), got ${d.length}`);return new Promise((a,b)=>{const e=n.bind(null,{resolve:a,reject:b});d.push(e),c.sendMessage(...d)})},p={devtools:{network:{onRequestFinished:k(l)}},runtime:{onMessage:k(m),onMessageExternal:k(m),sendMessage:o.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:o.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},q={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return b.privacy={network:{"*":q},services:{"*":q},websites:{"*":q}},j(a,p,b)})(chrome)}else a.exports=globalThis.browser});
//# sourceMappingURL=browser-polyfill.min.js.map

// webextension-polyfill v.0.12.0 (https://github.com/mozilla/webextension-polyfill)

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
// Listen for messages from the background script
browser.runtime.onMessage.addListener((message) => {
	//console.log("translatenow.js: received message from background script " + message.action);
	//console.log("translatenow.js: received data from background script " + JSON.stringify(message.data));

	switch(message.action){
		case "getSelection":
			sendMessage("setSelection", {selection: getSelection(message.data), pageUrl: window.location.href});
			//return Promise.resolve({selection: getSelection(message.data), pageUrl: window.location.href});
			break;
		case "bingTranslate":
			bingTranslate(message.data.translate_now_source_language, message.data.translate_now_destination_language, message.data.selectedText);
			break;
		case "bingSpeak":
			bingSpeak(message.data.translate_now_source_language, message.data.translate_now_destination_language, message.data.selectedText, message.data.translate_now_to_speak);
			break;
		case "googleSpeak":
			googleSpeak(message.data.translate_now_source_language, message.data.translate_now_destination_language, message.data.translate_now_to_speak);
			break;
		case "deeplSpeak":
			deeplSpeak(message.data.translate_now_source_language, message.data.translate_now_destination_language, message.data.selectedText, message.data.translate_now_to_speak);
			break;
		default:
			break;
	}
});

function sendMessage(action, data){
	browser.runtime.sendMessage({"action": action, "data": data});
}

function getSelection(safeSelection) {
	let inputSel = getInputSelection(document);
	if(inputSel != "") return inputSel;
	
	let normalSelection = window.getSelection().toString();
	if(normalSelection != "") return normalSelection;
	
	/// Code from Get Archive
	// Test URL: https://archive.is/2013.07.03-031317/http://neppi.blog.shinobi.jp/ねっぴーのこと/恩師増田宏三先生を悼む	
	let frameIdentifiers = ["iframe", "frame"];
	try{
		let i = 0;
		for(i = 0; i < frameIdentifiers.length; i++){
			let frames = document.getElementsByTagName(frameIdentifiers[i]);
			//console.log("number of frames: " + frames.length);
			
			let j = 0;
			for(j = 0; j < frames.length; j++){
				let frame = frames[j];

				let result = getIframeText(frame, window.location.href);
				if(result == "continue") continue;
				if(result != "exit") return result;
				
				for(k = 0; k < frameIdentifiers.length; k++){
					let innerFrames = frame.getElementsByTagName(frameIdentifiers[k]);
					
					for(l = 0; l < innerFrames.length; l++){
						let innerFrame = innerFrames[l];
						
						let result = getIframeText(innerFrame, frame.baseURI);
						if(result == "continue") continue;
						if(result != "exit") return result;
					}
				}
			}	
		}
	}catch(ex){
		// I don't trust the code above, return the default value at all times when there is an error with the code above
		console.log("Exception while getting the selection text from the frame: " + ex);
	}
	/// End of code from Get Archive
	
    return safeSelection;
}

function getIframeText(frame, parent){
	//console.log("baseURI: " + frame.document.baseURI + " parent is " + parent);
	try{		
		let doc = frame.document || frame.contentWindow || frame.contentDocument;

		let frameselection = doc.getSelection();
		
		if(frameselection == null){
			inputSel = getInputSelection(doc);
			if(inputSel != ""){
				return inputSel;
			}else{
				return "continue";
			}
		}else if(frameselection.toString().length > 0){
			//console.log("translatenow.js returning (i)frame selection");
			return frameselection.toString();
		}
		
		return "exit";
	}catch(innerex){
		//console.log("innerex " + innerex);
		//console.log("CROSS-DOMAIN IFRAME on URL " + frame.getAttribute("src"));
		return "exit";
	}
}

function getInputSelection(doc){
	try{
		if(doc.activeElement != null && (doc.activeElement.tagName === "TEXTAREA" || doc.activeElement.tagName === "INPUT")) {
			let inputSelectedText = doc.activeElement.value.substring(doc.activeElement.selectionStart, doc.activeElement.selectionEnd);
			if(inputSelectedText != null && inputSelectedText != ""){
				return inputSelectedText;
			}
		}
	}catch(ex){
		// I don't trust the code above, make sure we return an empty string so returning window.getSelection() will still work in the calling function
		return "";
	}
	return "";
}

function bingTranslate(translate_now_source_language, translate_now_destination_language, selectedText){
	sendMessage("log", "bing src language " + translate_now_source_language);
	setBingLanguage("tta_srcsl", translate_now_source_language.replace("auto", "auto-detect"));
	
	sendMessage("log", "bing dest language " + translate_now_destination_language);
	setBingLanguage("tta_tgtsl", translate_now_destination_language);
	
	let realDocument = document;
	setTimeout(function(){
		var textArea = realDocument.getElementById("tta_input_ta");
		textArea.value = selectedText;

		// Hack, but it works
		var suggestion = realDocument.querySelector(".tt_phTd");
		suggestion.textContent = selectedText;
		suggestion.click();
	}, 200);
}

function setBingLanguage(className, value){
	let select = document.getElementById(className);

	let options = select.getElementsByTagName("option");
	let i = 0;

    for(let item of options){
		if(item.value == value){
			select.selectedIndex = i;
			break;
		}
		i++;
	}
}

function bingSpeak(translate_now_source_language, translate_now_destination_language, selectedText, translate_now_to_speak){
	bingTranslate(translate_now_source_language, translate_now_destination_language, selectedText);
	
	setTimeout(function(){
		switch(translate_now_to_speak){
			case "original":
				bingSpeakSource();
				break;
			case "translation":
				bingSpeakDestination();
				break;
			case "both":
				setTimeout(function(){
					bingSpeakSource();
				}, 700);
				
				let length = 85 * selectedText.length;

				setTimeout(function(){
					if(document.getElementById("tta_input_ta").value != document.getElementById("tta_output_ta").value)
						bingSpeakDestination();
				}, length);
				
				break;
			default:
				break;
		}
	}, 3000);
}

//   document.querySelector("button[data-testid='translator-speaker-target']").click() 
function deeplSpeak(translate_now_source_language, translate_now_destination_language, selectedText, translate_now_to_speak){
	sendMessage("log", "translate_now_to_speak is " + translate_now_to_speak);
	
	switch(translate_now_to_speak){
		case "original":
			deeplSpeakOriginal(translate_now_source_language);
			break;
		case "translation":
			deeplSpeakTranslation(translate_now_destination_language);
			break;
		case "both":
			let result1 = deeplSpeakOriginal(translate_now_source_language);
			let result2 = deeplSpeakTranslation(translate_now_destination_language);
			if(result1 == false && result2 == false){
				sendMessage("notify", "Both - DeepL Translator Voice does not support other languages than English");
			}

			break;
		default:
			break;
	}
}

function deeplSpeakOriginal(translate_now_source_language, both){
	let supported = translate_now_source_language == "auto" || translate_now_source_language == "en";
	if(!supported){
		if(both == false) sendMessage("notify", "Original - DeepL Translator Voice does not support other languages than English");
		return false;
	}

	let element = document.querySelector("button[data-testid='translator-speaker-source']");
	if(element != null){
		element.click();
	}else{
		if(both == false) sendMessage("notify", "Original - DeepL Translator Voice could not find the audio button");
	}
	
	return true;
}

function deeplSpeakTranslation(translate_now_destination_language, both){
	let supported = translate_now_destination_language == "auto" || translate_now_destination_language == "en";
	if(!supported){
		if(both == false) sendMessage("notify", "Translation - DeepL Translator Voice does not support other languages than English");
		return false;
	}

	let element = document.querySelector("button[data-testid='translator-speaker-target']");
	if(element != null){
		element.click();
	}else{
		if(both == false) sendMessage("notify", "Translation - DeepL Translator Voice could not find the audio button");
	}
	
	return true;
}

function bingSpeakSource(){
	// POST https://www.bing.com/tfettts?isVertical=1&=&IG=63E6C7332DDC4184914D3E96D2D62B79&IID=translator.5024.1
	// &ssml=
	// <speak version='1.0' xml:lang='fr-FR'>
	// <voice xml:lang='fr-FR' xml:gender='Female' name='fr-FR-DeniseNeural'>
	// 		<prosody rate='-20.00%'>bla</prosody></voice>
	// </speak>
	//&token=1HDvGf7WVzLhnhs_5E8ZVl1nsEMEIUBI
	//&key=1703174914140
	
	setTimeout(function(){
		let speakButton = document.querySelector("#tta_playiconsrc");
		speakButton.click();
	}, 3000);
}

function bingSpeakDestination(){
	setTimeout(function(){
		let speakButton = document.querySelector("#tta_playicontgt");
		speakButton.click();
	}, 3000);
}

function googleSpeak(translate_now_source_language, translate_now_destination_language, translate_now_to_speak){
	switch(translate_now_to_speak){
		case "original":
			googleSpeakInternal(true, false);
			break;
		case "translation":
			googleSpeakInternal(false, true);
			break;
		case "both":
			let playDestination = getSourceText() != getDestinationText();
			googleSpeakInternal(true, playDestination); // play both if the texts aren't equal
			break;
		default:
			break;
	}
}

function googleSpeakInternal(playOriginal, playDestination){	
	let sourceText = getSourceText();
	let sourceDuration = 2500 + 85 * sourceText.length;
	
	let that = this;

	if(playOriginal){
		//this.document.querySelector(".m0Qfkd button span.material-icons-extended").click();
		document.querySelector(".m0Qfkd button span.material-icons-extended").children[0].click();

		/*let sourceSpeakLanguage = getSourceSpeakLanguage();
		if(sourceSpeakLanguage == "") sourceSpeakLanguage = "en";
	
		let audioObj = playSound(sourceSpeakLanguage, sourceText);
		sourceDuration = audioObj.duration * 1000;
		*/
	}
	
	if(playDestination){
		
		setTimeout(function(){
			//document.querySelector(".VO9ucd button span.material-icons-extended").click();
			that.document.querySelector(".VO9ucd button span.material-icons-extended").children[0].click();

			/*let destinationText = that.getDestinationText();
			let destinationSpeakLanguage = that.getDestinationSpeakLanguage();

			that.playSound(destinationSpeakLanguage, destinationText);*/
		}, sourceDuration + 150);
	}
	
	//googleSpeakPlayAfter(audioObj, playDestination);
}

/*function googleSpeakPlayAfter(audioObj, playDestination){
	if(!playDestination) return;
	
	let duration = 0;
	
	audioObj.addEventListener('loadedmetadata', function() {
		duration = audioObj.duration * 1000;
		googleSpeakDestination(audioObj.duration * 1000);
	});
	
	setTimeout(function(){
		if(duration == 0){
			googleSpeakDestination(0);
		}
	}, 2000);
}
*/

// document.querySelector(".VfPpkd-Bz112c-kBDsod").click() -> play source button
// document.querySelector(".VfPpkd-Bz112c-kBDsod").click() -> play source button


/* Google Translate (Speak) */
function playSound(speakLanguage, text){
	let speakUrl = googletranslate.getSpeakUrlSource(speakLanguage, text);
	let audioObj = new Audio(speakUrl);

	audioObj.play();
	return audioObj;
}
function getSourceSpeakLanguage(){
	let sourceLanguage = document.querySelector('#c66').getAttribute('data-language-code');
	
	return sourceLanguage;
}
function getSourceText(){
	let source = document.querySelector("textarea.er8xn");
	return source != null ? source.value : "";
}
function getDestinationSpeakLanguage(){
	let destinationLanguage = document.querySelector('#c7').getAttribute('data-language-code');
	return destinationLanguage;
}
function getDestinationText(){
	let resultBox = document.querySelector("#c71");
	return resultBox != null ? resultBox.innerText : "";
}
